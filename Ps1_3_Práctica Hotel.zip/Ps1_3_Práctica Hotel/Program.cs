﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace Ps1_3_Práctica_Hotel
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Aplicacion app = new Aplicacion();
            app.Inicio();
        }
    }
}
